/* Page d'administration : connexion Supabase + gestion des produits, points de vente,
   textes/photos et boîte de réception des messages du formulaire de contact. */
(function () {
  'use strict';
  var M = window.MARAICHER;
  var sb = M && M.sb;
  var BUCKET = (M && M.bucket) || 'photos';
  var UNITS = ['kg', 'pièce', 'botte', 'barquette', '500 g', 'panier', 'lot', 'litre'];
  var CATEGORIES = ['Légumes', 'Fruits', 'Aromates', 'Paniers', 'Autres'];
  var PAGE_ORDER = ['Général', 'Accueil', 'Qui sommes-nous', 'Le Domaine', 'Disponibilités', 'Recettes', 'Contact', 'Mentions légales'];
  var PAGE_LABEL = { 'Le Domaine': 'Qui sommes-nous' };
  var MONTH_NAMES = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  var MONTH_LETTERS = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
  var HINTS = {
    bandeau_annonce: 'Affiché tout en haut de chaque page (ex : fermeture météo ou arrivage). Laissez vide pour le masquer.',
    marches_horaires: 'Un lieu par ligne, avec le jour avant les deux-points. Ex : Mardi : Marché de la Vieille Ville — 7h à 13h',
    contact_email: "Laissez vide pour ne pas afficher d'email sur le site."
  };

  function $(s, r) { return (r || document).querySelector(s); }
  function el(tag, props, kids) {
    var e = document.createElement(tag);
    props = props || {};
    Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else if (v !== false && v !== null && v !== undefined) e.setAttribute(k, v);
    });
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined) return;
      e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return e;
  }

  /* ---------- Utilitaires ---------- */
  var toastTimer;
  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show ' + (kind || '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = 'toast'; }, 3400);
  }
  function show(sel, on) { $(sel).hidden = !on; }
  function msgOf(err) {
    var m = err && err.message ? String(err.message) : '';
    if (/row-level security|permission denied/i.test(m)) return 'Action refusée : droits insuffisants.';
    return m || 'Une erreur est survenue.';
  }
  function fail(err, fallback) {
    var m = err && err.message ? String(err.message) : '';
    if (/jwt|expired|not authenticated/i.test(m)) {
      showLogin('Votre session a expiré, reconnectez-vous.');
      return;
    }
    toast(err ? msgOf(err) : (fallback || 'Une erreur est survenue.'), 'err');
  }
  function okRows(r) { return !r.error && r.data && r.data.length > 0; }
  function parsePrice(s) {
    s = String(s || '').trim().replace(/\s/g, '').replace('€', '').replace(',', '.');
    if (s === '') return null;
    var n = Number(s);
    if (!isFinite(n) || n < 0 || n > 9999) return false;
    return Math.round(n * 100) / 100;
  }
  function priceText(p) { return (p === null || p === undefined) ? '' : String(p).replace('.', ','); }

  function buildSelect(options, current, label, onchange) {
    var list = options.slice();
    if (current && list.indexOf(current) < 0) list.unshift(current);
    var sel = el('select', { 'aria-label': label, onchange: onchange || null });
    list.forEach(function (item) {
      var o = el('option', { value: item, text: item });
      if (item === current) o.selected = true;
      sel.appendChild(o);
    });
    return sel;
  }

  // Bouton de suppression avec confirmation en 2 clics (sans popup window.confirm)
  function confirmDeleteBtn(onConfirm) {
    var armed = false;
    var timer = null;
    var btn = el('button', { type: 'button', class: 'btn btn-danger', text: 'Supprimer' });
    btn.addEventListener('click', async function () {
      if (!armed) {
        armed = true;
        btn.textContent = 'Confirmer ?';
        timer = setTimeout(function () {
          armed = false;
          btn.textContent = 'Supprimer';
        }, 4000);
        return;
      }
      clearTimeout(timer);
      armed = false;
      btn.disabled = true;
      await onConfirm();
      btn.disabled = false;
      btn.textContent = 'Supprimer';
    });
    return btn;
  }

  /* ---------- Images ---------- */
  function resizeImage(file, max, quality) {
    return new Promise(function (resolve, reject) {
      if (!/^image\//.test(file.type)) return reject(new Error("Ce fichier n'est pas une image."));
      var img = new Image();
      var url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var r = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement('canvas');
        c.width = Math.round(img.width * r);
        c.height = Math.round(img.height * r);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        c.toBlob(function (b) { b ? resolve(b) : reject(new Error('Conversion impossible.')); }, 'image/jpeg', quality);
      };
      img.onerror = function () { reject(new Error('Image illisible (essayez un fichier JPG ou PNG).')); };
      img.src = url;
    });
  }
  function uploadImage(file, folder) {
    return resizeImage(file, 1600, 0.85).then(function (blob) {
      var path = folder + '/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '.jpg';
      return sb.storage.from(BUCKET).upload(path, blob, { contentType: 'image/jpeg', cacheControl: '31536000', upsert: false })
        .then(function (r) {
          if (r.error) throw r.error;
          return sb.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
        });
    });
  }
  function removeImage(url) {
    if (!url) return;
    var marker = '/object/public/' + BUCKET + '/';
    var i = url.indexOf(marker);
    if (i < 0) return;
    try { sb.storage.from(BUCKET).remove([decodeURIComponent(url.slice(i + marker.length))]); } catch (e) {}
  }
  function setThumb(box, url) {
    box.textContent = '';
    box.classList.toggle('empty', !url);
    if (url) box.appendChild(el('img', { src: url, alt: '' }));
  }

  /* ---------- Connexion ---------- */
  function showLogin(msg) {
    show('#app', false); show('#bar', false); show('#login', true);
    $('#login-error').textContent = msg || '';
  }

  async function enter(session) {
    var r = await sb.rpc('is_admin');
    if (r.error || r.data !== true) {
      await sb.auth.signOut();
      showLogin("Ce compte n'a pas les droits d'administration.");
      return;
    }
    show('#login', false); show('#app', true); show('#bar', true);
    $('#who').textContent = session.user.email || '';
    await Promise.all([loadProducts(), loadSpots(), loadTexts(), loadMessages(), loadSeason(), loadRecipes(), loadGallery()]);
  }

  /* ---------- Produits ---------- */
  var products = [];
  var supportsCategory = true;

  async function loadProducts() {
    var r = await sb.from('legumes').select('*')
      .order('ordre', { ascending: true }).order('id', { ascending: true });
    if (r.error) return fail(r.error, 'Impossible de charger les produits.');
    products = r.data || [];
    if (products.length > 0 && !Object.prototype.hasOwnProperty.call(products[0], 'categorie')) {
      supportsCategory = false;
    }
    renderProducts();
  }

  function renderProducts() {
    var box = $('#product-list');
    box.textContent = '';
    if (!products.length) {
      box.appendChild(el('p', { class: 'empty-note', text: "Aucun produit pour l'instant. Utilisez « ＋ Ajouter un produit »." }));
      return;
    }
    products.forEach(function (p, i) { box.appendChild(productRow(p, i)); });
  }

  function hasUnsaved() { return !!document.querySelector('.dirty'); }

  async function move(i, d) {
    var j = i + d;
    if (j < 0 || j >= products.length) return;
    if (hasUnsaved()) { toast("Enregistrez d'abord vos modifications en cours.", 'err'); return; }
    var a = products.slice();
    var t = a[i]; a[i] = a[j]; a[j] = t;
    var jobs = [];
    a.forEach(function (p, k) {
      if (p.ordre !== k) {
        jobs.push(sb.from('legumes').update({ ordre: k }).eq('id', p.id).select());
        p.ordre = k;
      }
    });
    var res = await Promise.all(jobs);
    if (res.some(function (r) { return !okRows(r); })) {
      toast('Réorganisation refusée.', 'err');
      return loadProducts();
    }
    products = a;
    renderProducts();
  }

  function productRow(p, i) {
    var row = el('article', { class: 'prow' + (p.disponible ? '' : ' off') });
    function markDirty() { saveBtn.disabled = false; row.classList.add('dirty'); }

    // Photo
    var thumb = el('div', { class: 'thumb' });
    setThumb(thumb, p.image_url);
    var fileInput = el('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async function () {
      var f = fileInput.files[0];
      if (!f) return;
      photoBtn.disabled = true;
      try {
        var url = await uploadImage(f, 'produits');
        var r = await sb.from('legumes').update({ image_url: url }).eq('id', p.id).select();
        if (!okRows(r)) throw (r.error || new Error('Modification refusée.'));
        removeImage(p.image_url);
        p.image_url = url;
        setThumb(thumb, url);
        photoBtn.textContent = 'Changer';
        rmBtn.hidden = false;
        toast('Photo mise à jour ✓');
      } catch (err) { fail(err); }
      photoBtn.disabled = false;
      fileInput.value = '';
    } });
    var photoBtn = el('button', { type: 'button', class: 'btn btn-ghost', text: p.image_url ? 'Changer' : '＋ Photo',
      onclick: function () { fileInput.click(); } });
    var rmBtn = el('button', { type: 'button', class: 'btn btn-ghost', text: 'Retirer', hidden: !p.image_url, onclick: async function () {
      var r = await sb.from('legumes').update({ image_url: null }).eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Modification refusée.');
      removeImage(p.image_url);
      p.image_url = null;
      setThumb(thumb, null);
      photoBtn.textContent = '＋ Photo';
      rmBtn.hidden = true;
      toast('Photo retirée ✓');
    } });
    var photoCol = el('div', {}, [thumb, el('div', { class: 'photo-actions' }, [photoBtn, rmBtn, fileInput])]);

    // Champs
    var nom = el('input', { type: 'text', value: p.nom || '', maxlength: 80, oninput: markDirty });
    var prix = el('input', { type: 'text', inputmode: 'decimal', value: priceText(p.prix), placeholder: '3,50', oninput: markDirty });
    var unite = buildSelect(UNITS, p.unite, 'Unité', markDirty);
    var cat = buildSelect(CATEGORIES, p.categorie || 'Légumes', 'Catégorie', markDirty);
    var desc = el('textarea', { rows: 2, maxlength: 300, placeholder: 'Description (facultatif)', oninput: markDirty }, [p.description || '']);

    var fieldNodes = [
      el('div', { class: 'name' }, [el('label', { text: 'Nom' }), nom]),
      el('div', {}, [el('label', { text: 'Prix (€)' }), prix]),
      el('div', {}, [el('label', { text: 'Unité' }), unite])
    ];
    if (supportsCategory) {
      fieldNodes.push(el('div', {}, [el('label', { text: 'Catégorie' }), cat]));
    }
    fieldNodes.push(el('div', { class: 'wide' }, [el('label', { text: 'Description' }), desc]));
    var fields = el('div', { class: 'pfields' }, fieldNodes);

    // Disponibilité (enregistrée tout de suite)
    var sw = el('input', { type: 'checkbox', role: 'switch' });
    sw.checked = !!p.disponible;
    var swText = el('span', { text: p.disponible ? 'Disponible' : 'Indisponible' });
    sw.addEventListener('change', async function () {
      var want = sw.checked;
      var r = await sb.from('legumes').update({ disponible: want }).eq('id', p.id).select();
      if (!okRows(r)) { sw.checked = !want; return fail(r.error, 'Modification refusée.'); }
      p.disponible = want;
      swText.textContent = want ? 'Disponible' : 'Indisponible';
      row.classList.toggle('off', !want);
      toast(want ? p.nom + ' : visible sur le site ✓' : p.nom + ' : retiré du site ✓');
    });
    var sw_label = el('label', { class: 'switch' }, [sw, el('span', { class: 'slider' }), swText]);

    // Actions
    var saveBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Enregistrer', disabled: true, onclick: async function () {
      var price = parsePrice(prix.value);
      var name = nom.value.trim();
      if (!name) return toast('Le nom est obligatoire.', 'err');
      if (price === false) return toast('Prix invalide (exemple : 3,50).', 'err');
      saveBtn.disabled = true;
      var patch = { nom: name, prix: price, unite: unite.value, description: desc.value.trim() || null };
      if (supportsCategory) patch.categorie = cat.value;
      var r = await sb.from('legumes').update(patch).eq('id', p.id).select();
      if (!okRows(r)) { saveBtn.disabled = false; return fail(r.error, 'Modification refusée.'); }
      p.nom = name; p.prix = price; p.unite = unite.value; p.description = desc.value.trim() || null;
      if (supportsCategory) p.categorie = cat.value;
      row.classList.remove('dirty');
      toast('Enregistré ✓');
    } });

    var delBtn = confirmDeleteBtn(async function () {
      var r = await sb.from('legumes').delete().eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
      removeImage(p.image_url);
      toast('Produit supprimé ✓');
      loadProducts();
    });

    var up = el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Monter', text: '▲', disabled: i === 0, onclick: function () { move(i, -1); } });
    var down = el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Descendre', text: '▼', disabled: i === products.length - 1, onclick: function () { move(i, 1); } });

    var side = el('div', { class: 'pside' }, [
      sw_label,
      el('div', { class: 'pbtns' }, [up, down, saveBtn, delBtn])
    ]);

    [photoCol, fields, side].forEach(function (c) { row.appendChild(c); });
    return row;
  }

  function setupAddForm() {
    var sel = $('#a-unite');
    UNITS.forEach(function (u) { sel.appendChild(el('option', { value: u, text: u })); });

    var catSel = $('#a-cat');
    CATEGORIES.forEach(function (c) { catSel.appendChild(el('option', { value: c, text: c })); });

    // Aperçu photo en direct avant l'envoi
    var previewUrl = null;
    var photoInput = $('#a-photo');
    var previewBox = $('#a-photo-preview');
    photoInput.addEventListener('change', function () {
      if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
      var file = photoInput.files[0];
      if (!file) { setThumb(previewBox, null); return; }
      previewUrl = URL.createObjectURL(file);
      setThumb(previewBox, previewUrl);
    });

    $('#add-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      var name = $('#a-nom').value.trim();
      var price = parsePrice($('#a-prix').value);
      if (!name) return toast('Le nom est obligatoire.', 'err');
      if (price === false) return toast('Prix invalide (exemple : 3,50).', 'err');
      var btn = $('#a-submit');
      btn.disabled = true;
      try {
        var file = photoInput.files[0];
        var photo = file ? await uploadImage(file, 'produits') : null;
        var ordre = products.length ? Math.max.apply(null, products.map(function (p) { return p.ordre || 0; })) + 1 : 0;
        var payload = {
          nom: name, prix: price, unite: sel.value,
          description: $('#a-desc').value.trim() || null,
          image_url: photo, disponible: $('#a-dispo').checked, ordre: ordre
        };
        if (supportsCategory) payload.categorie = catSel.value;

        var r = await sb.from('legumes').insert(payload).select();
        // Rétrocompatibilité si la migration SQL n'a pas encore ajouté la colonne `categorie`
        if (r.error && /categorie/i.test(r.error.message || '')) {
          supportsCategory = false;
          delete payload.categorie;
          r = await sb.from('legumes').insert(payload).select();
        }
        if (!okRows(r)) throw (r.error || new Error('Ajout refusé.'));
        $('#add-form').reset();
        if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
        setThumb(previewBox, null);
        $('#add-box').open = false;
        toast(name + ' ajouté ✓');
        await loadProducts();
      } catch (err) { fail(err); }
      btn.disabled = false;
    });
  }

  /* ---------- Points de vente ---------- */
  var spots = [];

  function geocode(q) {
    var url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=fr&countrycodes=fr,ch,it&q=' + encodeURIComponent(q);
    return fetch(url, { headers: { Accept: 'application/json' } }).then(function (r) {
      if (!r.ok) throw new Error("Le service de recherche d'adresse est indisponible, réessayez dans un instant.");
      return r.json();
    }).then(function (j) {
      if (!j.length) throw new Error("Adresse introuvable. Précisez la ville (ex : « Rue de l'Isle, Annecy »).");
      return { lat: Math.round(parseFloat(j[0].lat) * 1e6) / 1e6, lng: Math.round(parseFloat(j[0].lon) * 1e6) / 1e6 };
    });
  }
  function parseCoord(v, max) {
    v = String(v || '').trim().replace(',', '.');
    if (v === '') return null;
    var n = Number(v);
    if (!isFinite(n) || Math.abs(n) > max) return false;
    return n;
  }

  async function loadSpots() {
    var r = await sb.from('points_vente').select('*')
      .order('ordre', { ascending: true }).order('id', { ascending: true });
    if (r.error) return fail(r.error, 'Impossible de charger les points de vente.');
    spots = r.data || [];
    var box = $('#spot-list');
    box.textContent = '';
    if (!spots.length) {
      box.appendChild(el('p', { class: 'empty-note', text: "Aucun point de vente. La carte est masquée sur le site tant qu'il n'y en a pas." }));
      return;
    }
    spots.forEach(function (p) { box.appendChild(spotRow(p)); });
  }

  function spotRow(p) {
    var row = el('article', { class: 'srow' });
    function markDirty() { saveBtn.disabled = false; row.classList.add('dirty'); }
    var nom = el('input', { type: 'text', value: p.nom || '', maxlength: 80, oninput: markDirty });
    var adr = el('input', { type: 'text', value: p.adresse || '', maxlength: 160, oninput: markDirty });
    var hor = el('input', { type: 'text', value: p.horaires || '', maxlength: 100, placeholder: 'Mardi · 7h à 13h', oninput: markDirty });
    var lat = el('input', { type: 'text', inputmode: 'decimal', value: p.lat === null || p.lat === undefined ? '' : String(p.lat), oninput: markDirty });
    var lng = el('input', { type: 'text', inputmode: 'decimal', value: p.lng === null || p.lng === undefined ? '' : String(p.lng), oninput: markDirty });
    var status = el('span', { class: 'status' });
    var mapLink = el('a', { class: 'btn btn-ghost', target: '_blank', rel: 'noopener', text: 'Vérifier sur la carte ↗' });

    function refreshStatus() {
      var la = parseCoord(lat.value, 90);
      var lo = parseCoord(lng.value, 180);
      var ok = la !== null && lo !== null && la !== false && lo !== false;
      status.className = 'status ' + (ok ? 'ok' : 'warn');
      status.textContent = ok ? '✓ Placé sur la carte' : '⚠ Pas de position : cliquez sur Localiser';
      mapLink.hidden = !ok;
      if (ok) mapLink.href = 'https://www.openstreetmap.org/?mlat=' + la + '&mlon=' + lo + '#map=17/' + la + '/' + lo;
    }

    var locBtn = el('button', { type: 'button', class: 'btn btn-ghost', text: '📍 Localiser', onclick: async function () {
      var q = (adr.value.trim() || nom.value.trim());
      if (!q) return toast("Saisissez une adresse d'abord.", 'err');
      locBtn.disabled = true;
      try {
        var g = await geocode(q);
        lat.value = g.lat; lng.value = g.lng;
        markDirty(); refreshStatus();
        toast('Adresse localisée ✓ Vérifiez, puis enregistrez.');
      } catch (err) { toast(msgOf(err), 'err'); }
      locBtn.disabled = false;
    } });
    var saveBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Enregistrer', disabled: true, onclick: async function () {
      var name = nom.value.trim();
      var la = parseCoord(lat.value, 90), lo = parseCoord(lng.value, 180);
      if (!name) return toast('Le nom est obligatoire.', 'err');
      if (la === false || lo === false) return toast('Coordonnées invalides.', 'err');
      if ((la === null) !== (lo === null)) return toast('Renseignez la latitude ET la longitude (ou cliquez sur Localiser).', 'err');
      saveBtn.disabled = true;
      var r = await sb.from('points_vente').update({
        nom: name, adresse: adr.value.trim() || null, horaires: hor.value.trim() || null, lat: la, lng: lo
      }).eq('id', p.id).select();
      if (!okRows(r)) { saveBtn.disabled = false; return fail(r.error, 'Modification refusée.'); }
      row.classList.remove('dirty');
      refreshStatus();
      toast('Point de vente enregistré ✓');
    } });
    var delBtn = confirmDeleteBtn(async function () {
      var r = await sb.from('points_vente').delete().eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
      toast('Point de vente supprimé ✓');
      loadSpots();
    });
    lat.addEventListener('input', refreshStatus);
    lng.addEventListener('input', refreshStatus);

    [
      el('div', {}, [el('label', { text: 'Nom' }), nom]),
      el('div', {}, [el('label', { text: 'Adresse' }), adr]),
      el('div', {}, [el('label', { text: 'Jours et horaires' }), hor]),
      el('div', { class: 'coords' }, [
        el('div', {}, [el('label', { text: 'Latitude' }), lat]),
        el('div', {}, [el('label', { text: 'Longitude' }), lng])
      ]),
      el('div', { class: 'sbtns' }, [locBtn, mapLink, saveBtn, delBtn, status])
    ].forEach(function (c) { row.appendChild(c); });
    refreshStatus();
    return row;
  }

  function setupSpotForm() {
    $('#add-spot-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      var name = $('#s-nom').value.trim();
      var adr = $('#s-adr').value.trim();
      if (!name) return toast('Le nom est obligatoire.', 'err');
      var btn = $('#s-submit');
      btn.disabled = true;
      var coords = { lat: null, lng: null }, warn = '';
      try {
        if (adr || name) coords = await geocode(adr || name);
      } catch (err) { warn = msgOf(err); }
      var ordre = spots.length ? Math.max.apply(null, spots.map(function (s) { return s.ordre || 0; })) + 1 : 0;
      var r = await sb.from('points_vente').insert({
        nom: name, adresse: adr || null, horaires: $('#s-hor').value.trim() || null,
        lat: coords.lat, lng: coords.lng, ordre: ordre
      }).select();
      if (!okRows(r)) { btn.disabled = false; return fail(r.error, 'Ajout refusé.'); }
      $('#add-spot-form').reset();
      $('#add-spot-box').open = false;
      if (warn) toast('Ajouté, mais sans position. ' + warn, 'err'); else toast(name + ' ajouté sur la carte ✓');
      btn.disabled = false;
      loadSpots();
    });
  }

  /* ---------- Textes & photos ---------- */
  async function loadTexts() {
    var r = await sb.from('contenu_site').select('*').order('ordre', { ascending: true });
    if (r.error) return fail(r.error, 'Impossible de charger les textes.');
    var groups = {};
    (r.data || []).forEach(function (row) { (groups[row.page] = groups[row.page] || []).push(row); });
    var names = Object.keys(groups).sort(function (a, b) {
      var ia = PAGE_ORDER.indexOf(a), ib = PAGE_ORDER.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    var box = $('#texts');
    box.textContent = '';
    names.forEach(function (n, idx) { box.appendChild(textGroup(n, groups[n], idx === 0)); });
  }

  function textGroup(name, rows, open) {
    var changed = {};
    var saveBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Enregistrer cette page', disabled: true });
    var det = el('details', { class: 'group' }, [el('summary', { text: PAGE_LABEL[name] || name })]);
    if (open) det.open = true;
    var body = el('div', { class: 'group-body' });

    function dirty(row, input) {
      changed[row.cle] = input;
      saveBtn.disabled = false;
      det.classList.add('dirty');
    }

    rows.forEach(function (row) {
      var id = 'f-' + row.cle;
      var wrap = el('div', { class: 'tfield field' });
      wrap.appendChild(el('label', { for: id, text: row.libelle }));

      if (row.type === 'image') {
        var thumb = el('div', { class: 'thumb' });
        setThumb(thumb, row.valeur);
        var file = el('input', { type: 'file', accept: 'image/*', hidden: true, id: id, onchange: async function () {
          var f = file.files[0];
          if (!f) return;
          chooseBtn.disabled = true;
          try {
            var url = await uploadImage(f, 'site');
            var r = await sb.from('contenu_site').update({ valeur: url, updated_at: new Date().toISOString() }).eq('cle', row.cle).select();
            if (!okRows(r)) throw (r.error || new Error('Modification refusée.'));
            removeImage(row.valeur);
            row.valeur = url;
            setThumb(thumb, url);
            chooseBtn.textContent = 'Changer la photo';
            clearBtn.hidden = false;
            toast('Photo enregistrée ✓');
          } catch (err) { fail(err); }
          chooseBtn.disabled = false;
          file.value = '';
        } });
        var chooseBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: row.valeur ? 'Changer la photo' : 'Choisir une photo',
          onclick: function () { file.click(); } });
        var clearBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Retirer', hidden: !row.valeur, onclick: async function () {
          var r = await sb.from('contenu_site').update({ valeur: '', updated_at: new Date().toISOString() }).eq('cle', row.cle).select();
          if (!okRows(r)) return fail(r.error, 'Modification refusée.');
          removeImage(row.valeur);
          row.valeur = '';
          setThumb(thumb, null);
          chooseBtn.textContent = 'Choisir une photo';
          clearBtn.hidden = true;
          toast('Photo retirée ✓');
        } });
        wrap.appendChild(el('div', { class: 'timg' }, [thumb, el('div', { class: 'photo-actions' }, [chooseBtn, clearBtn, file])]));
        wrap.appendChild(el('p', { class: 'hint', text: 'Sans photo, une illustration par défaut est affichée.' }));
      } else {
        var input;
        if (row.type === 'paragraphe') {
          var n = String(row.valeur || '').split('\n').length;
          input = el('textarea', { id: id, rows: Math.min(10, Math.max(3, n + 1)) }, [row.valeur || '']);
        } else {
          input = el('input', { id: id, type: 'text', value: row.valeur || '' });
        }
        input.addEventListener('input', function () { dirty(row, input); });
        wrap.appendChild(input);
        if (HINTS[row.cle]) wrap.appendChild(el('p', { class: 'hint', text: HINTS[row.cle] }));
      }
      body.appendChild(wrap);
    });

    saveBtn.addEventListener('click', async function () {
      var keys = Object.keys(changed);
      if (!keys.length) return;
      saveBtn.disabled = true;
      var now = new Date().toISOString();
      var res = await Promise.all(keys.map(function (k) {
        return sb.from('contenu_site').update({ valeur: changed[k].value, updated_at: now }).eq('cle', k).select();
      }));
      var bad = res.filter(function (r) { return !okRows(r); });
      if (bad.length) {
        saveBtn.disabled = false;
        return fail(bad[0].error, 'Certaines modifications ont été refusées.');
      }
      changed = {};
      det.classList.remove('dirty');
      toast('Textes enregistrés ✓ — le site est à jour');
    });

    body.appendChild(el('div', { class: 'save-row' }, [saveBtn]));
    det.appendChild(body);
    return det;
  }


  /* ---------- Sélecteur de mois (calendrier et recettes) ---------- */
  function monthPicker(selected, onchange) {
    var on = {};
    (selected || []).forEach(function (m) { on[m] = true; });
    var wrap = el('div', { class: 'months', role: 'group', 'aria-label': 'Mois' });
    var btns = [];
    function paint() {
      btns.forEach(function (b, i) {
        b.classList.toggle('on', !!on[i + 1]);
        b.setAttribute('aria-pressed', on[i + 1] ? 'true' : 'false');
      });
    }
    MONTH_LETTERS.forEach(function (l, i) {
      var b = el('button', { type: 'button', class: 'month', text: l, title: MONTH_NAMES[i], onclick: function () {
        on[i + 1] = !on[i + 1];
        paint();
        if (onchange) onchange();
      } });
      btns.push(b);
      wrap.appendChild(b);
    });
    var all = el('button', { type: 'button', class: 'month-all', text: "Toute l'année", onclick: function () {
      var full = Object.keys(on).filter(function (k) { return on[k]; }).length === 12;
      for (var m = 1; m <= 12; m++) on[m] = !full;
      paint();
      if (onchange) onchange();
    } });
    wrap.appendChild(all);
    paint();
    return {
      node: wrap,
      get: function () {
        var out = [];
        for (var m = 1; m <= 12; m++) if (on[m]) out.push(m);
        return out;
      },
      reset: function () { on = {}; paint(); }
    };
  }

  function notActivated(box, what) {
    box.textContent = '';
    box.appendChild(el('div', { class: 'empty-note' }, [
      el('strong', { text: what + ' pas encore activé(e) dans Supabase.' }),
      el('p', { style: 'margin:8px 0 0', text: 'Exécutez le fichier supabase-migration-v2_5.sql dans le SQL Editor de Supabase.' })
    ]));
  }

  /* ---------- Calendrier de saison ---------- */
  var season = [];
  var seasonPicker = null;

  async function loadSeason() {
    var box = $('#season-list');
    var r = await sb.from('calendrier_saison').select('*').order('nom', { ascending: true });
    if (r.error) { notActivated(box, 'Le calendrier de saison'); $('#add-season-box').hidden = true; return; }
    $('#add-season-box').hidden = false;
    season = (r.data || []).slice().sort(function (a, b) { return String(a.nom).localeCompare(String(b.nom), 'fr'); });
    box.textContent = '';
    if (!season.length) {
      box.appendChild(el('p', { class: 'empty-note', text: 'Calendrier vide : il est masqué sur le site. Ajoutez un premier produit.' }));
      return;
    }
    season.forEach(function (p) { box.appendChild(seasonRow(p)); });
  }

  function seasonRow(p) {
    var row = el('article', { class: 'crow' });
    function markDirty() { saveBtn.disabled = false; row.classList.add('dirty'); }
    var nom = el('input', { type: 'text', value: p.nom || '', maxlength: 60, 'aria-label': 'Nom', oninput: markDirty });
    var picker = monthPicker(p.mois, markDirty);
    var saveBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Enregistrer', disabled: true, onclick: async function () {
      var name = nom.value.trim();
      if (!name) return toast('Le nom est obligatoire.', 'err');
      saveBtn.disabled = true;
      var r = await sb.from('calendrier_saison').update({ nom: name, mois: picker.get() }).eq('id', p.id).select();
      if (!okRows(r)) { saveBtn.disabled = false; return fail(r.error, 'Modification refusée.'); }
      p.nom = name; p.mois = picker.get();
      row.classList.remove('dirty');
      toast('Calendrier enregistré ✓');
    } });
    var delBtn = confirmDeleteBtn(async function () {
      var r = await sb.from('calendrier_saison').delete().eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
      toast('Produit retiré du calendrier ✓');
      loadSeason();
    });
    row.appendChild(el('div', { class: 'cname' }, [nom]));
    row.appendChild(picker.node);
    row.appendChild(el('div', { class: 'pbtns' }, [saveBtn, delBtn]));
    return row;
  }

  function setupSeasonForm() {
    seasonPicker = monthPicker([]);
    $('#c-months').appendChild(seasonPicker.node);
    $('#add-season-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      var name = $('#c-nom').value.trim();
      if (!name) return toast('Le nom est obligatoire.', 'err');
      var btn = $('#c-submit');
      btn.disabled = true;
      var r = await sb.from('calendrier_saison').insert({ nom: name, mois: seasonPicker.get() }).select();
      btn.disabled = false;
      if (!okRows(r)) return fail(r.error, 'Ajout refusé.');
      $('#add-season-form').reset();
      seasonPicker.reset();
      toast(name + ' ajouté ✓');
      loadSeason();
    });
  }

  /* ---------- Recettes ---------- */
  var recipes = [];
  var recipePicker = null;

  function parseIntField(v, min, max) {
    v = String(v || '').trim();
    if (v === '') return null;
    var n = Number(v);
    if (!isFinite(n) || n % 1 !== 0 || n < min || n > max) return false;
    return n;
  }

  async function loadRecipes() {
    var box = $('#recipe-list');
    var r = await sb.from('recettes').select('*').order('created_at', { ascending: false }).order('id', { ascending: false });
    if (r.error) { notActivated(box, 'Les recettes'); $('#add-recipe-box').hidden = true; return; }
    $('#add-recipe-box').hidden = false;
    recipes = r.data || [];
    box.textContent = '';
    if (!recipes.length) {
      box.appendChild(el('p', { class: 'empty-note', text: "Aucune recette. Utilisez « ＋ Ajouter une recette »." }));
      return;
    }
    recipes.forEach(function (p) { box.appendChild(recipeRow(p)); });
  }

  function recipeRow(p) {
    var det = el('details', { class: 'rcard' + (p.publie ? '' : ' off') });
    function markDirty() { saveBtn.disabled = false; det.classList.add('dirty'); }

    var summary = el('summary', {}, [
      el('span', { class: 'rtitle', text: p.titre }),
      el('span', { class: 'rstate', text: p.publie ? 'Publiée' : 'Brouillon' })
    ]);

    var thumb = el('div', { class: 'thumb' });
    setThumb(thumb, p.image_url);
    var fileInput = el('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async function () {
      var f = fileInput.files[0];
      if (!f) return;
      photoBtn.disabled = true;
      try {
        var url = await uploadImage(f, 'recettes');
        var r = await sb.from('recettes').update({ image_url: url }).eq('id', p.id).select();
        if (!okRows(r)) throw (r.error || new Error('Modification refusée.'));
        removeImage(p.image_url);
        p.image_url = url;
        setThumb(thumb, url);
        photoBtn.textContent = 'Changer';
        rmBtn.hidden = false;
        toast('Photo mise à jour ✓');
      } catch (err) { fail(err); }
      photoBtn.disabled = false;
      fileInput.value = '';
    } });
    var photoBtn = el('button', { type: 'button', class: 'btn btn-ghost', text: p.image_url ? 'Changer' : '＋ Photo', onclick: function () { fileInput.click(); } });
    var rmBtn = el('button', { type: 'button', class: 'btn btn-ghost', text: 'Retirer', hidden: !p.image_url, onclick: async function () {
      var r = await sb.from('recettes').update({ image_url: null }).eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Modification refusée.');
      removeImage(p.image_url);
      p.image_url = null;
      setThumb(thumb, null);
      photoBtn.textContent = '＋ Photo';
      rmBtn.hidden = true;
      toast('Photo retirée ✓');
    } });

    var titre = el('input', { type: 'text', value: p.titre || '', maxlength: 120, oninput: markDirty });
    var duree = el('input', { type: 'text', inputmode: 'numeric', value: p.duree_min == null ? '' : String(p.duree_min), oninput: markDirty });
    var pers = el('input', { type: 'text', inputmode: 'numeric', value: p.personnes == null ? '' : String(p.personnes), oninput: markDirty });
    var desc = el('textarea', { rows: 2, maxlength: 400, oninput: markDirty }, [p.description || '']);
    var ing = el('textarea', { rows: 6, maxlength: 3000, oninput: markDirty }, [p.ingredients || '']);
    var etapes = el('textarea', { rows: 6, maxlength: 6000, oninput: markDirty }, [p.etapes || '']);
    var picker = monthPicker(p.mois, markDirty);
    var pub = el('input', { type: 'checkbox', onchange: markDirty });
    pub.checked = !!p.publie;

    var saveBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Enregistrer', disabled: true, onclick: async function () {
      var t = titre.value.trim();
      var d = parseIntField(duree.value, 1, 1440), n = parseIntField(pers.value, 1, 100);
      if (!t) return toast('Le titre est obligatoire.', 'err');
      if (d === false) return toast('Durée invalide (en minutes, ex : 30).', 'err');
      if (n === false) return toast('Nombre de personnes invalide.', 'err');
      saveBtn.disabled = true;
      var patch = {
        titre: t, description: desc.value.trim() || null, ingredients: ing.value.trim(), etapes: etapes.value.trim(),
        duree_min: d, personnes: n, mois: picker.get(), publie: pub.checked
      };
      var r = await sb.from('recettes').update(patch).eq('id', p.id).select();
      if (!okRows(r)) { saveBtn.disabled = false; return fail(r.error, 'Modification refusée.'); }
      Object.keys(patch).forEach(function (k) { p[k] = patch[k]; });
      summary.querySelector('.rtitle').textContent = t;
      summary.querySelector('.rstate').textContent = p.publie ? 'Publiée' : 'Brouillon';
      det.classList.toggle('off', !p.publie);
      det.classList.remove('dirty');
      toast('Recette enregistrée ✓');
    } });
    var delBtn = confirmDeleteBtn(async function () {
      var r = await sb.from('recettes').delete().eq('id', p.id).select();
      if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
      removeImage(p.image_url);
      toast('Recette supprimée ✓');
      loadRecipes();
    });

    function f(label, input, cls) { return el('div', { class: 'field ' + (cls || '') }, [el('label', { text: label }), input]); }
    var body = el('div', { class: 'rbody' }, [
      el('div', { class: 'rphoto' }, [thumb, el('div', { class: 'photo-actions' }, [photoBtn, rmBtn, fileInput])]),
      el('div', { class: 'rfields' }, [
        f('Titre', titre, 'span-2'), f('Durée (min)', duree), f('Personnes', pers),
        f('Description courte', desc, 'wide'),
        f('Ingrédients (un par ligne)', ing, 'wide'),
        f('Préparation (une étape par ligne)', etapes, 'wide'),
        f("Saison (vide = toute l'année)", picker.node, 'wide'),
        el('label', { class: 'check wide' }, [pub, ' Publiée sur le site'])
      ]),
      el('div', { class: 'pbtns rbtns' }, [saveBtn, delBtn])
    ]);
    det.appendChild(summary);
    det.appendChild(body);
    return det;
  }

  function setupRecipeForm() {
    recipePicker = monthPicker([]);
    $('#r-months').appendChild(recipePicker.node);
    var previewUrl = null;
    var photoInput = $('#r-photo');
    var previewBox = $('#r-photo-preview');
    photoInput.addEventListener('change', function () {
      if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
      var file = photoInput.files[0];
      if (!file) { setThumb(previewBox, null); return; }
      previewUrl = URL.createObjectURL(file);
      setThumb(previewBox, previewUrl);
    });
    $('#add-recipe-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      var t = $('#r-titre').value.trim();
      var d = parseIntField($('#r-duree').value, 1, 1440), n = parseIntField($('#r-pers').value, 1, 100);
      if (!t) return toast('Le titre est obligatoire.', 'err');
      if (d === false) return toast('Durée invalide (en minutes, ex : 30).', 'err');
      if (n === false) return toast('Nombre de personnes invalide.', 'err');
      var btn = $('#r-submit');
      btn.disabled = true;
      try {
        var file = photoInput.files[0];
        var photo = file ? await uploadImage(file, 'recettes') : null;
        var r = await sb.from('recettes').insert({
          titre: t, description: $('#r-desc').value.trim() || null,
          ingredients: $('#r-ing').value.trim(), etapes: $('#r-etapes').value.trim(),
          duree_min: d, personnes: n, mois: recipePicker.get(), image_url: photo, publie: $('#r-pub').checked
        }).select();
        if (!okRows(r)) throw (r.error || new Error('Ajout refusé.'));
        $('#add-recipe-form').reset();
        recipePicker.reset();
        if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
        setThumb(previewBox, null);
        $('#add-recipe-box').open = false;
        toast('Recette ajoutée ✓');
        await loadRecipes();
      } catch (err) { fail(err); }
      btn.disabled = false;
    });
  }


  /* ---------- Galerie photos ---------- */
  var gallery = [];

  async function loadGallery() {
    var box = $('#gallery-list');
    var r = await sb.from('galerie').select('*').order('ordre', { ascending: true }).order('id', { ascending: true });
    if (r.error) { notActivated(box, 'La galerie'); $('.gal-add').hidden = true; return; }
    $('.gal-add').hidden = false;
    gallery = r.data || [];
    renderGallery();
  }

  function renderGallery() {
    var box = $('#gallery-list');
    box.textContent = '';
    if (!gallery.length) {
      box.appendChild(el('p', { class: 'empty-note', text: 'Aucune photo pour le moment : la section « En images » est masquée sur le site.' }));
      return;
    }
    gallery.forEach(function (g, i) { box.appendChild(galleryCard(g, i)); });
  }

  async function moveGallery(i, d) {
    var j = i + d;
    if (j < 0 || j >= gallery.length) return;
    var a = gallery.slice();
    var t = a[i]; a[i] = a[j]; a[j] = t;
    var jobs = [];
    a.forEach(function (g, k) {
      if (g.ordre !== k) { jobs.push(sb.from('galerie').update({ ordre: k }).eq('id', g.id).select()); g.ordre = k; }
    });
    var res = await Promise.all(jobs);
    if (res.some(function (r) { return !okRows(r); })) { toast('Réorganisation refusée.', 'err'); return loadGallery(); }
    gallery = a;
    renderGallery();
  }

  function galleryCard(g, i) {
    var thumb = el('div', { class: 'gal-thumb' });
    setThumb(thumb, g.image_url);
    var cap = el('input', { type: 'text', value: g.legende || '', maxlength: 140, placeholder: 'Légende (facultatif)', 'aria-label': 'Légende',
      onchange: async function () {
        var v = cap.value.trim() || null;
        var r = await sb.from('galerie').update({ legende: v }).eq('id', g.id).select();
        if (!okRows(r)) return fail(r.error, 'Modification refusée.');
        g.legende = v;
        toast('Légende enregistrée ✓');
      } });
    var up = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '◀', title: 'Avancer', 'aria-label': 'Déplacer avant', disabled: i === 0, onclick: function () { moveGallery(i, -1); } });
    var down = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '▶', title: 'Reculer', 'aria-label': 'Déplacer après', disabled: i === gallery.length - 1, onclick: function () { moveGallery(i, 1); } });
    var del = confirmDeleteBtn(async function () {
      var r = await sb.from('galerie').delete().eq('id', g.id).select();
      if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
      removeImage(g.image_url);
      toast('Photo supprimée ✓');
      loadGallery();
    });
    return el('article', { class: 'gal-card' }, [thumb, cap, el('div', { class: 'gal-actions' }, [up, down, del])]);
  }

  function setupGalleryForm() {
    var input = $('#g-files'), status = $('#g-status'), btn = $('#g-add');
    btn.addEventListener('click', function () { input.click(); });
    input.addEventListener('change', async function () {
      var files = Array.prototype.slice.call(input.files || []);
      if (!files.length) return;
      btn.disabled = true;
      var ordre = gallery.length ? Math.max.apply(null, gallery.map(function (g) { return g.ordre || 0; })) + 1 : 0;
      var done = 0, errors = 0;
      for (var n = 0; n < files.length; n++) {
        status.textContent = 'Envoi de la photo ' + (n + 1) + ' sur ' + files.length + '…';
        try {
          var url = await uploadImage(files[n], 'galerie');
          var r = await sb.from('galerie').insert({ image_url: url, ordre: ordre + done }).select();
          if (!okRows(r)) { removeImage(url); throw (r.error || new Error('Ajout refusé.')); }
          done++;
        } catch (err) { errors++; fail(err, 'Une photo n’a pas pu être ajoutée.'); }
      }
      status.textContent = '';
      input.value = '';
      btn.disabled = false;
      if (done) toast(done + (done > 1 ? ' photos ajoutées ✓' : ' photo ajoutée ✓'));
      await loadGallery();
    });
  }

  /* ---------- Messages du formulaire de contact ---------- */
  var messages = [];

  function formatDate(iso) {
    try {
      return new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso));
    } catch (e) {
      return '';
    }
  }

  function updateUnreadBadge() {
    var badge = $('#unread-badge');
    if (!badge) return;
    var count = messages.filter(function (m) { return !m.lu; }).length;
    badge.textContent = String(count);
    badge.hidden = count === 0;
  }

  async function loadMessages() {
    var box = $('#messages-list');
    if (!box) return;
    var r = await sb.from('messages_contact').select('*').order('created_at', { ascending: false });
    if (r.error) {
      box.textContent = '';
      box.appendChild(el('div', { class: 'empty-note' }, [
        el('strong', { text: 'Boîte de réception non encore activée dans Supabase.' }),
        el('p', { style: 'margin:8px 0 0', text: 'Exécutez le fichier supabase-migration.sql dans le SQL Editor de Supabase pour recevoir les messages ici.' })
      ]));
      return;
    }
    messages = r.data || [];
    updateUnreadBadge();
    renderMessages();
  }

  function renderMessages() {
    var box = $('#messages-list');
    box.textContent = '';
    updateUnreadBadge();
    if (!messages.length) {
      box.appendChild(el('p', { class: 'empty-note', text: 'Aucun message reçu pour le moment.' }));
      return;
    }
    messages.forEach(function (m) {
      var card = el('article', { class: 'msg-card' + (m.lu ? '' : ' unread') });
      var metaText = ' · ' + m.email + (m.telephone ? ' · ' + m.telephone : '');
      var head = el('div', { class: 'msg-head' }, [
        el('div', {}, [
          el('span', { class: 'msg-who', text: m.nom }),
          el('span', { class: 'msg-meta', text: metaText })
        ]),
        el('span', { class: 'msg-meta', text: formatDate(m.created_at) })
      ]);

      var readBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: m.lu ? 'Marquer non lu' : 'Marquer comme lu', onclick: async function () {
        var next = !m.lu;
        var r = await sb.from('messages_contact').update({ lu: next }).eq('id', m.id).select();
        if (!okRows(r)) return fail(r.error, 'Modification refusée.');
        m.lu = next;
        renderMessages();
      } });

      var replyLink = el('a', {
        class: 'btn btn-primary btn-sm',
        href: 'mailto:' + encodeURI(String(m.email).trim()) + '?subject=' + encodeURIComponent('Re : ' + (m.objet || 'Votre message')),
        text: 'Répondre par email'
      });

      var delBtn = confirmDeleteBtn(async function () {
        var r = await sb.from('messages_contact').delete().eq('id', m.id).select();
        if (!okRows(r)) return fail(r.error, 'Suppression refusée.');
        messages = messages.filter(function (x) { return x.id !== m.id; });
        toast('Message supprimé ✓');
        renderMessages();
      });
      delBtn.classList.add('btn-sm');

      card.appendChild(head);
      if (m.objet) card.appendChild(el('span', { class: 'msg-subject', text: m.objet }));
      card.appendChild(el('p', { class: 'msg-body', text: m.message }));
      card.appendChild(el('div', { class: 'msg-actions' }, [readBtn, replyLink, delBtn]));
      box.appendChild(card);
    });
  }

  /* ---------- Démarrage ---------- */
  function init() {
    if (!sb) {
      showLogin('Impossible de joindre le service (connexion internet ?). Rechargez la page.');
      return;
    }
    setupAddForm();
    setupSpotForm();
    setupSeasonForm();
    setupRecipeForm();
    setupGalleryForm();

    Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (t) {
      t.addEventListener('click', function () {
        Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (x) {
          var on = x === t;
          x.classList.toggle('active', on);
          x.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        ['produits', 'points', 'calendrier', 'recettes', 'galerie', 'textes', 'messages'].forEach(function (name) {
          show('#tab-' + name, t.dataset.tab === name);
        });
        if (t.dataset.tab === 'messages') loadMessages();
      });
    });

    $('#login-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      var btn = e.target.querySelector('button[type=submit]');
      btn.disabled = true;
      $('#login-error').textContent = '';
      var r = await sb.auth.signInWithPassword({ email: $('#email').value.trim(), password: $('#password').value });
      btn.disabled = false;
      if (r.error || !r.data || !r.data.session) {
        $('#login-error').textContent = 'Email ou mot de passe incorrect.';
        return;
      }
      $('#password').value = '';
      await enter(r.data.session);
    });

    $('#logout').addEventListener('click', async function () {
      await sb.auth.signOut();
      showLogin();
    });

    window.addEventListener('beforeunload', function (e) {
      if (hasUnsaved()) { e.preventDefault(); e.returnValue = ''; }
    });

    sb.auth.getSession().then(function (r) {
      if (r.data && r.data.session) enter(r.data.session); else showLogin();
    });
  }

  init();
})();
