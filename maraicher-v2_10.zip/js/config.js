/* Configuration Supabase.
   La clé "publishable" est faite pour être publique : la sécurité repose
   sur les règles RLS de la base (lecture publique, écriture réservée à l'admin). */
window.MARAICHER = (function () {
  var URL = 'https://viegmnlexnyznxuiuqra.supabase.co';
  var KEY = 'sb_publishable_3J7V_1B5kS1cV7phBNMKjg_i4EcxRrb';
  var sb = (window.supabase && window.supabase.createClient)
    ? window.supabase.createClient(URL, KEY)
    : null;
  return { sb: sb, url: URL, bucket: 'photos' };
})();
