/* Site public : charge les textes, produits et points de vente depuis Supabase,
   et envoie les messages du formulaire de contact vers la boîte de réception admin. */
(function () {
  'use strict';
  var sb = window.MARAICHER && window.MARAICHER.sb;
  var root = document.documentElement;

  function each(sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); }
  function ready() { root.classList.remove('c-pending'); }
  setTimeout(ready, 2500); // garde-fou : ne jamais laisser la page masquée

  /* ---------- Menu mobile ---------- */
  var burger = document.querySelector('.burger');
  var menu = document.getElementById('menu');
  if (burger && menu) {
    burger.addEventListener('click', function () {
      var open = menu.classList.toggle('open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  each('[data-year]', function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- Textes & photos ---------- */
  function lines(text) {
    return String(text || '').split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function applyContent(map) {
    var has = function (k) { return Object.prototype.hasOwnProperty.call(map, k); };

    if (has('site_nom') && map.site_nom) {
      var suffix = document.body.getAttribute('data-page-suffix');
      document.title = map.site_nom + (suffix ? ' | ' + suffix : '');
    }

    each('[data-c]', function (el) {
      var k = el.getAttribute('data-c');
      if (has(k)) el.textContent = map[k] || '';
    });

    each('[data-c-lines]', function (el) {
      var k = el.getAttribute('data-c-lines');
      if (!has(k)) return;
      el.textContent = '';
      lines(map[k]).forEach(function (l) {
        var p = document.createElement('p');
        p.textContent = l;
        el.appendChild(p);
      });
    });

    each('[data-c-hours]', function (el) {
      var k = el.getAttribute('data-c-hours');
      if (!has(k)) return;
      el.textContent = '';
      lines(map[k]).forEach(function (l) {
        var li = document.createElement('li');
        var i = l.indexOf(':');
        if (i > 0 && i < 24) {
          var s = document.createElement('strong');
          s.textContent = l.slice(0, i).trim();
          var sp = document.createElement('span');
          sp.textContent = l.slice(i + 1).trim();
          li.appendChild(s); li.appendChild(sp);
        } else {
          var only = document.createElement('span');
          only.textContent = l;
          li.style.gridTemplateColumns = '1fr';
          li.appendChild(only);
        }
        el.appendChild(li);
      });
    });

    each('[data-c-img]', function (img) {
      var k = img.getAttribute('data-c-img');
      if (!has(k)) return;
      var box = img.closest('[data-media]');
      var src = map[k] || img.getAttribute('data-fallback') || '';
      if (src) {
        img.src = src;
        img.hidden = false;
        if (box) box.classList.add('has-photo');
      } else {
        img.hidden = true;
        if (box) box.classList.remove('has-photo');
      }
    });

    each('[data-c-tel]', function (a) {
      var k = a.getAttribute('data-c-tel');
      if (!has(k)) return;
      a.textContent = map[k] || '';
      a.href = 'tel:' + String(map[k] || '').replace(/[^\d+]/g, '');
    });

    each('[data-c-mail]', function (a) {
      var k = a.getAttribute('data-c-mail');
      if (!has(k)) return;
      a.textContent = map[k] || '';
      a.href = 'mailto:' + (map[k] || '');
    });

    each('[data-if]', function (el) {
      var k = el.getAttribute('data-if');
      if (has(k)) el.hidden = !String(map[k] || '').trim();
    });
  }

  function loadContent() {
    if (!sb) { ready(); setupToday(); return Promise.resolve(); }
    return sb.from('contenu_site').select('cle,valeur').then(function (res) {
      if (res.error || !res.data) return;
      var map = {};
      res.data.forEach(function (r) { map[r.cle] = r.valeur; });
      applyContent(map);
    }).catch(function () {}).then(function () { ready(); setupToday(); });
  }

  /* ---------- Produits & filtres catégories ---------- */
  var fmt = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' });
  function priceLabel(p) {
    if (p.prix === null || p.prix === undefined || p.prix === '') return '';
    return fmt.format(Number(p.prix)) + (p.unite ? ' / ' + p.unite : '');
  }


  /* ---------- Liste de réservation (sans paiement, envoyée par message) ---------- */
  var RESA_KEY = 'lm_resa_v1';
  var resa = [];
  var resaSubs = [];
  var resaFocus = null;
  var nfQty = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 });
  var STEPS = { 'kg': 0.5, 'litre': 0.5 };
  function stepOf(u) { return STEPS[u] || 1; }

  function resaClean(a) {
    var out = [];
    if (!Array.isArray(a)) return out;
    a.forEach(function (it) {
      if (!it || (typeof it.id !== 'number' && typeof it.id !== 'string')) return;
      var q = Number(it.qty);
      if (!(q > 0) || q > 99) return;
      var pr = (it.prix === null || it.prix === undefined || it.prix === '') ? null : Number(it.prix);
      out.push({
        id: it.id,
        nom: String(it.nom || '').slice(0, 80),
        unite: String(it.unite || '').slice(0, 20),
        prix: (pr === null || isNaN(pr)) ? null : pr,
        qty: Math.round(q * 100) / 100
      });
    });
    return out;
  }
  function resaRead() {
    try { return resaClean(JSON.parse(localStorage.getItem(RESA_KEY) || '[]')); } catch (e) { return resa; }
  }
  function resaNotify() {
    resaSubs = resaSubs.filter(function (fn) { return fn() !== false; });
  }
  function resaSave() {
    try { localStorage.setItem(RESA_KEY, JSON.stringify(resa)); } catch (e) {}
    resaNotify();
  }
  function resaGet(id) {
    for (var i = 0; i < resa.length; i++) if (String(resa[i].id) === String(id)) return resa[i];
    return null;
  }
  function resaSet(p, qty) {
    qty = Math.round(qty * 100) / 100;
    var cur = resaGet(p.id);
    if (qty < 0.01) {
      resa = resa.filter(function (it) { return String(it.id) !== String(p.id); });
    } else {
      qty = Math.min(qty, 99);
      var pr = (p.prix === null || p.prix === undefined || p.prix === '') ? null : Number(p.prix);
      if (cur) { cur.qty = qty; }
      else resa.push({ id: p.id, nom: String(p.nom || ''), unite: String(p.unite || ''), prix: isNaN(pr) ? null : pr, qty: qty });
    }
    resaSave();
  }
  function resaClear() { resa = []; resaSave(); }
  function resaPrune(ids) {
    var keep = {};
    ids.forEach(function (i) { keep[String(i)] = true; });
    var before = resa.length;
    resa = resa.filter(function (it) { return keep[String(it.id)]; });
    if (resa.length !== before) resaSave();
  }
  function onResa(fn) { resaSubs.push(fn); }
  resa = resaRead();
  window.addEventListener('storage', function (e) {
    if (e.key === RESA_KEY) { resa = resaRead(); resaNotify(); }
  });

  function qtyText(it) {
    var n = nfQty.format(it.qty), u = it.unite || '';
    if (!u) return n;
    if (u === 'kg') return n + ' kg';
    if (u === '500 g') return n + ' × 500 g';
    return n + ' ' + u + ((it.qty >= 2 && !/[sx]$/.test(u)) ? 's' : '');
  }
  function resaTotal() {
    var t = 0;
    for (var i = 0; i < resa.length; i++) {
      if (resa[i].prix === null) return null;
      t += resa[i].prix * resa[i].qty;
    }
    return resa.length ? t : null;
  }
  function resaMessage(retrait, note) {
    var lines = resa.map(function (it) {
      return '– ' + qtyText(it) + ' ' + it.nom +
        (it.prix !== null ? ' (' + fmt.format(it.prix) + (it.unite ? ' / ' + it.unite : '') + ')' : '');
    });
    var tot = resaTotal();
    var msg = 'Bonjour,\nJe souhaiterais réserver :\n' + lines.join('\n');
    if (tot !== null) msg += '\nTotal indicatif : ' + fmt.format(tot);
    if (retrait) msg += '\nRetrait souhaité : ' + retrait;
    if (note) msg += '\n\n' + note;
    return msg;
  }

  function applyResaFocus(root) {
    if (!resaFocus) return;
    var groups = root.querySelectorAll('[data-pid]');
    for (var i = 0; i < groups.length; i++) {
      if (groups[i].getAttribute('data-pid') === String(resaFocus.id)) {
        var t = groups[i].querySelector('.' + resaFocus.cls);
        if (t) { t.focus(); resaFocus = null; return; }
      }
    }
  }

  // Sélecteur de quantité (− 1,5 kg +)
  function buildStepper(it) {
    var g = document.createElement('div');
    g.className = 'qty';
    g.setAttribute('role', 'group');
    g.setAttribute('aria-label', 'Quantité : ' + it.nom);
    g.setAttribute('data-pid', String(it.id));
    var step = stepOf(it.unite);
    function btn(cls, label, txt, delta) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'q-btn ' + cls;
      b.setAttribute('aria-label', label + ' – ' + it.nom);
      b.textContent = txt;
      b.addEventListener('click', function () {
        var cur = resaGet(it.id) || it;
        var next = cur.qty + delta;
        resaFocus = { id: it.id, cls: next < 0.01 ? 'q-add' : cls };
        resaSet(it, next);
      });
      return b;
    }
    var val = document.createElement('span');
    val.className = 'q-val';
    val.textContent = qtyText(it).replace(/ /g, ' ');
    g.appendChild(btn('q-minus', 'Retirer', '−', -step));
    g.appendChild(val);
    g.appendChild(btn('q-plus', 'Ajouter', '+', step));
    return g;
  }

  // Contrôle d'une fiche produit : « + Ajouter » puis sélecteur
  function resaControl(p) {
    var wrap = document.createElement('div');
    wrap.className = 'resa-ctl';
    var seen = false;
    function draw() {
      wrap.textContent = '';
      var cur = resaGet(p.id);
      if (cur) {
        wrap.appendChild(buildStepper(cur));
      } else {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'product-ask q-add';
        b.setAttribute('data-pid', String(p.id));
        b.setAttribute('aria-label', 'Ajouter ' + (p.nom || 'ce produit') + ' à ma réservation');
        b.textContent = 'Ajouter';
        b.addEventListener('click', function () {
          resaFocus = { id: p.id, cls: 'q-plus' };
          resaSet(p, 1);
        });
        var holder = document.createElement('span');
        holder.setAttribute('data-pid', String(p.id));
        holder.appendChild(b);
        wrap.appendChild(holder);
      }
      applyResaFocus(wrap);
    }
    draw();
    onResa(function () {
      if (document.body.contains(wrap)) seen = true;
      else if (seen) return false;
      draw();
    });
    return wrap;
  }

  // Barre flottante « Ma réservation » (toutes les pages sauf contact)
  function setupResaBar() {
    if (document.getElementById('contact-form')) return;
    var bar = document.createElement('div');
    bar.className = 'resa-bar';
    bar.setAttribute('role', 'region');
    bar.setAttribute('aria-label', 'Ma réservation');
    bar.hidden = true;
    var count = document.createElement('span');
    count.className = 'resa-count';
    count.setAttribute('aria-live', 'polite');
    var a = document.createElement('a');
    a.className = 'btn btn-light btn-sm';
    a.href = '/contact#reservation';
    a.textContent = 'Envoyer ma demande';
    bar.appendChild(count); bar.appendChild(a);
    document.body.appendChild(bar);
    function draw() {
      var n = resa.length;
      bar.hidden = !n;
      document.body.classList.toggle('has-resa', n > 0);
      count.textContent = n ? (n + ' produit' + (n > 1 ? 's choisis' : ' choisi')) : '';
    }
    draw();
    onResa(draw);
  }

  function productCard(p) {
    var art = document.createElement('article');
    art.className = 'product';
    var imgBox = document.createElement('div');
    imgBox.className = 'product-img' + (p.image_url ? '' : ' empty');
    if (p.image_url) {
      var img = document.createElement('img');
      img.src = p.image_url; img.alt = p.nom || ''; img.loading = 'lazy';
      imgBox.appendChild(img);
    }
    var body = document.createElement('div');
    body.className = 'product-body';
    if (p.categorie) {
      var cat = document.createElement('span');
      cat.className = 'product-cat';
      cat.textContent = p.categorie;
      body.appendChild(cat);
    }
    var h = document.createElement('h3'); h.textContent = p.nom;
    body.appendChild(h);
    if (p.description) {
      var d = document.createElement('p'); d.textContent = p.description;
      body.appendChild(d);
    }
    var pr = priceLabel(p);
    var foot = document.createElement('div');
    foot.className = 'product-foot';
    var pe = document.createElement('div');
    pe.className = 'price';
    pe.textContent = pr || 'Prix sur étal';
    foot.appendChild(pe);

    foot.appendChild(resaControl(p));

    body.appendChild(foot);
    art.appendChild(imgBox); art.appendChild(body);
    return art;
  }

  function renderProductBox(box, fullList, activeCat) {
    var section = box.closest('[data-products-section]') || box.parentNode;
    var empty = section.querySelector('[data-products-empty]');
    var err = section.querySelector('[data-products-error]');
    box.textContent = '';

    var list = (activeCat && activeCat !== 'Tous')
      ? fullList.filter(function (p) { return p.categorie === activeCat; })
      : fullList.slice();

    var limit = parseInt(box.getAttribute('data-limit') || '0', 10);
    if (limit > 0) list = list.slice(0, limit);

    if (!list.length) {
      if (empty) empty.hidden = false;
      if (section.hasAttribute('data-hide-when-empty')) section.hidden = true;
      return;
    }
    if (empty) empty.hidden = true;
    if (err) err.hidden = true;
    section.hidden = false;
    list.forEach(function (p) { box.appendChild(productCard(p)); });
  }

  function setupCategoryFilters(section, box, fullList) {
    var filterBar = section.querySelector('[data-cat-filters]');
    if (!filterBar) return;
    var cats = [];
    fullList.forEach(function (p) {
      if (p.categorie && cats.indexOf(p.categorie) < 0) cats.push(p.categorie);
    });
    if (cats.length < 2) {
      filterBar.hidden = true;
      return;
    }
    var allCats = ['Tous'].concat(cats);
    var activeCat = 'Tous';

    function drawFilters() {
      filterBar.textContent = '';
      allCats.forEach(function (cat) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cat-btn' + (cat === activeCat ? ' active' : '');
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', cat === activeCat ? 'true' : 'false');
        btn.textContent = cat;
        btn.addEventListener('click', function () {
          activeCat = cat;
          drawFilters();
          renderProductBox(box, fullList, activeCat);
        });
        filterBar.appendChild(btn);
      });
    }
    filterBar.hidden = false;
    drawFilters();
  }

  function loadProducts() {
    var boxes = document.querySelectorAll('[data-products]');
    if (!boxes.length || !sb) return Promise.resolve();
    return sb.from('legumes')
      .select('*')
      .eq('disponible', true)
      .order('ordre', { ascending: true })
      .order('id', { ascending: true })
      .then(function (res) {
        Array.prototype.forEach.call(boxes, function (box) {
          var section = box.closest('[data-products-section]') || box.parentNode;
          var empty = section.querySelector('[data-products-empty]');
          var err = section.querySelector('[data-products-error]');
          if (res.error) {
            box.textContent = '';
            if (err) err.hidden = false;
            if (empty) empty.hidden = true;
            return;
          }
          var fullList = res.data || [];
          if (box === boxes[0]) resaPrune(fullList.map(function (x) { return x.id; }));
          setupCategoryFilters(section, box, fullList);
          renderProductBox(box, fullList, 'Tous');
        });
      }).catch(function () {
        each('[data-products-error]', function (e) { e.hidden = false; });
      });
  }

  /* ---------- Carte des points de vente ---------- */
  function hasCoords(p) {
    return p.lat !== null && p.lat !== undefined && p.lng !== null && p.lng !== undefined &&
      isFinite(p.lat) && isFinite(p.lng);
  }

  function spotInfo(p, withLink) {
    var box = document.createElement('div');
    var h = document.createElement('strong');
    h.textContent = p.nom;
    box.appendChild(h);
    if (p.horaires) { var t = document.createElement('div'); t.className = 'spot-h'; t.textContent = p.horaires; box.appendChild(t); }
    if (p.adresse) { var a = document.createElement('div'); a.className = 'spot-a'; a.textContent = p.adresse; box.appendChild(a); }
    if (withLink && hasCoords(p)) {
      var l = document.createElement('a');
      l.href = 'https://www.google.com/maps/dir/?api=1&destination=' + p.lat + ',' + p.lng;
      l.target = '_blank'; l.rel = 'noopener';
      l.textContent = 'Itinéraire →';
      box.appendChild(l);
      var ap = document.createElement('a');
      ap.href = 'https://maps.apple.com/?daddr=' + p.lat + ',' + p.lng + '&dirflg=d';
      ap.target = '_blank'; ap.rel = 'noopener';
      ap.className = 'spot-alt';
      ap.textContent = 'Plans';
      box.appendChild(ap);
    }
    return box;
  }

  function loadMap() {
    var sec = document.querySelector('[data-map-section]');
    if (!sec || !sb) return Promise.resolve();
    return sb.from('points_vente')
      .select('id,nom,adresse,horaires,lat,lng,ordre')
      .order('ordre', { ascending: true }).order('id', { ascending: true })
      .then(function (res) {
        if (res.error || !res.data || !res.data.length) return;
        var pts = res.data;
        sec.hidden = false;
        var mapEl = document.getElementById('map');
        var list = document.getElementById('spots');
        var located = pts.filter(hasCoords);
        var map = null, markers = {};

        if (window.L && located.length) {
          map = L.map(mapEl, { scrollWheelZoom: false });
          L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          }).addTo(map);
          var icon = L.divIcon({ className: 'pin', html: '<span></span>', iconSize: [30, 30], iconAnchor: [15, 30], popupAnchor: [0, -30] });
          located.forEach(function (p) {
            markers[p.id] = L.marker([p.lat, p.lng], { icon: icon, title: p.nom })
              .addTo(map).bindPopup(spotInfo(p, true));
          });
          if (located.length === 1) map.setView([located[0].lat, located[0].lng], 15);
          else map.fitBounds(L.latLngBounds(located.map(function (p) { return [p.lat, p.lng]; })), { padding: [40, 40], maxZoom: 15 });
          setTimeout(function () { map.invalidateSize(); }, 200);
        } else {
          mapEl.hidden = true;
          sec.querySelector('.map-grid').classList.add('no-map');
        }

        pts.forEach(function (p) {
          var li = document.createElement('li');
          li.className = 'spot';
          li.appendChild(spotInfo(p, true));
          if (map && markers[p.id]) {
            li.classList.add('clickable');
            li.addEventListener('click', function (e) {
              if (e.target.tagName === 'A') return;
              map.flyTo([p.lat, p.lng], Math.max(map.getZoom(), 15), { duration: 0.6 });
              markers[p.id].openPopup();
            });
          }
          list.appendChild(li);
        });
      }).catch(function () {});
  }



  /* ---------- Typographie française (espaces insécables), y compris pour les textes saisis dans l'admin ---------- */
  function typoFix(node) {
    var walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        var p = n.parentNode && n.parentNode.nodeName;
        return /^(SCRIPT|STYLE|TEXTAREA|INPUT|NOSCRIPT|CODE)$/.test(p) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      }
    });
    var n, list = [];
    while ((n = walker.nextNode())) list.push(n);
    list.forEach(function (t) {
      var v = t.nodeValue;
      var w = v.replace(/(\S) ([?!:;»])/g, '$1 $2').replace(/(«) /g, '$1 ').replace(/(\d) (€|%|kg\b|g\b)/g, '$1 $2');
      if (w !== v) t.nodeValue = w;
    });
  }
  function startTypo() {
    typoFix(document.body);
    if (!window.MutationObserver) return;
    var timer = null;
    new MutationObserver(function () {
      clearTimeout(timer);
      timer = setTimeout(function () { typoFix(document.body); }, 60);
    }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startTypo); else startTypo();

  /* ---------- Heure et mois à Paris (indépendant du fuseau du visiteur) ---------- */
  var DAYS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var DAYS_LABEL = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  var MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  var MONTHS_SHORT = ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'];

  function parisNow() {
    var d = new Date();
    try {
      var parts = {};
      new Intl.DateTimeFormat('fr-FR', {
        timeZone: 'Europe/Paris', weekday: 'long', hour: 'numeric', minute: 'numeric', month: 'numeric', hour12: false
      }).formatToParts(d).forEach(function (p) { parts[p.type] = p.value; });
      var wd = DAYS.indexOf(String(parts.weekday).toLowerCase());
      if (wd < 0) throw new Error('weekday');
      return { day: wd, minutes: (parseInt(parts.hour, 10) % 24) * 60 + parseInt(parts.minute, 10), month: parseInt(parts.month, 10) };
    } catch (e) {
      return { day: d.getDay(), minutes: d.getHours() * 60 + d.getMinutes(), month: d.getMonth() + 1 };
    }
  }

  /* ---------- Bandeau « ouvert aujourd'hui » (calculé depuis les horaires affichés) ---------- */
  function plain(str) {
    return String(str || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  function daysIn(label) {
    var t = plain(label), out = [], i;
    if (/tous les jours|7j|7 j/.test(t)) return [0, 1, 2, 3, 4, 5, 6];
    var range = t.match(/(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\s+(?:au|a|->|-)\s+(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)/);
    if (range) {
      var from = DAYS.indexOf(range[1]), to = DAYS.indexOf(range[2]);
      for (i = from; ; i = (i + 1) % 7) { out.push(i); if (i === to) break; }
      return out;
    }
    DAYS.forEach(function (n, k) { if (t.indexOf(n) >= 0) out.push(k); });
    return out;
  }
  var TIME_RE = /(\d{1,2})\s*h\s*(\d{2})?\s*(?:à|a|au|-|–|—)\s*(\d{1,2})\s*h\s*(\d{2})?/i;
  function hLabel(min) {
    var h = Math.floor(min / 60), m = min % 60;
    return h + 'h' + (m ? (m < 10 ? '0' + m : m) : '');
  }
  function readSlots(list) {
    var slots = [];
    Array.prototype.forEach.call(list.querySelectorAll('li'), function (li) {
      var strong = li.querySelector('strong'), span = li.querySelector('span');
      if (!strong || !span) return;
      var days = daysIn(strong.textContent);
      if (!days.length) return;
      var txt = span.textContent.trim();
      var t = txt.match(TIME_RE);
      var place = txt.replace(TIME_RE, '').replace(/[\s—–\-·:,]+$/, '').replace(/^[\s—–\-·:,]+/, '').trim();
      days.forEach(function (d) {
        slots.push({
          day: d, place: place,
          start: t ? parseInt(t[1], 10) * 60 + parseInt(t[2] || '0', 10) : null,
          end: t ? parseInt(t[3], 10) * 60 + parseInt(t[4] || '0', 10) : null
        });
      });
    });
    return slots;
  }
  function slotText(sl, withTimes) {
    var parts = [];
    if (sl.place) parts.push(sl.place);
    if (withTimes && sl.start !== null) parts.push(hLabel(sl.start) + ' à ' + hLabel(sl.end));
    return parts.join(' · ');
  }

  function renderToday(slots) {
    var now = parisNow();
    var state = null, text = '', sl;
    var todays = slots.filter(function (x) { return x.day === now.day; })
      .sort(function (a, b) { return (a.start || 0) - (b.start || 0); });

    for (var i = 0; i < todays.length && !state; i++) {
      sl = todays[i];
      if (sl.start === null) { state = 'today'; text = 'Aujourd’hui : ' + slotText(sl, false); }
      else if (now.minutes >= sl.start && now.minutes < sl.end) { state = 'open'; text = 'Ouvert maintenant : ' + slotText(sl, false) + ' · jusqu’à ' + hLabel(sl.end); }
      else if (now.minutes < sl.start) { state = 'today'; text = 'Aujourd’hui : ' + slotText(sl, true); }
    }
    if (!state) {
      for (var k = 1; k <= 7 && !state; k++) {
        var d = (now.day + k) % 7;
        var c = slots.filter(function (x) { return x.day === d; }).sort(function (a, b) { return (a.start || 0) - (b.start || 0); })[0];
        if (c) { state = 'next'; text = 'Prochaine vente : ' + (k === 1 ? 'demain' : DAYS[d]) + ' · ' + slotText(c, true); }
      }
    }
    return { state: state, text: text };
  }

  function setupToday() {
    var boxes = document.querySelectorAll('[data-today]');
    var list = document.querySelector('[data-c-hours]');
    if (!boxes.length || !list) return;
    function draw() {
      var slots = readSlots(list);
      var r = slots.length ? renderToday(slots) : { state: null };
      each('[data-today]', function (b) {
        if (!r.state) { b.hidden = true; return; }
        b.hidden = false;
        b.className = 'today is-' + r.state;
        b.querySelector('.today-text').textContent = r.text;
      });
    }
    draw();
    setInterval(draw, 60000);
  }

  /* ---------- Calendrier de saison ---------- */
  function loadSeason() {
    var sec = document.querySelector('[data-season-section]');
    if (!sec || !sb) return Promise.resolve();
    return sb.from('calendrier_saison').select('id,nom,mois').then(function (res) {
      if (res.error || !res.data || !res.data.length) return;
      var rows = res.data.slice().sort(function (a, b) { return String(a.nom).localeCompare(String(b.nom), 'fr'); });
      var cur = parisNow().month;
      var table = sec.querySelector('[data-season-table]');
      table.textContent = '';

      var thead = document.createElement('thead');
      var hr = document.createElement('tr');
      var corner = document.createElement('th');
      corner.scope = 'col'; corner.className = 'season-name';
      corner.textContent = 'Produit';
      hr.appendChild(corner);
      MONTHS_SHORT.forEach(function (m, i) {
        var th = document.createElement('th');
        th.scope = 'col';
        th.className = 'season-m' + (i + 1 === cur ? ' now' : '');
        var ab = document.createElement('abbr');
        ab.title = MONTHS[i]; ab.textContent = m;
        th.appendChild(ab);
        hr.appendChild(th);
      });
      thead.appendChild(hr);
      table.appendChild(thead);

      var tbody = document.createElement('tbody');
      var nowList = [];
      rows.forEach(function (r) {
        var months = r.mois || [];
        if (months.indexOf(cur) >= 0) nowList.push(r.nom);
        var tr = document.createElement('tr');
        var th = document.createElement('th');
        th.scope = 'row'; th.className = 'season-name';
        th.textContent = r.nom;
        tr.appendChild(th);
        for (var m = 1; m <= 12; m++) {
          var td = document.createElement('td');
          var on = months.indexOf(m) >= 0;
          td.className = (on ? 'on' : '') + (m === cur ? ' now' : '');
          var sr = document.createElement('span');
          sr.className = 'sr-only';
          sr.textContent = on ? 'De saison' : 'Hors saison';
          td.appendChild(sr);
          tr.appendChild(td);
        }
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);

      var now = sec.querySelector('[data-season-now]');
      if (nowList.length) {
        now.hidden = false;
        now.textContent = '';
        var b = document.createElement('strong');
        b.textContent = 'En ce moment (' + MONTHS[cur - 1] + ') : ';
        now.appendChild(b);
        now.appendChild(document.createTextNode(nowList.join(', ') + '.'));
      }
      sec.hidden = false;
    }).catch(function () {});
  }

  /* ---------- Recettes ---------- */
  function cleanLines(text, stripNumbers) {
    return lines(text).map(function (l) {
      l = l.replace(/^[-•*]\s*/, '');
      return stripNumbers ? l.replace(/^\d+\s*[.)]\s*/, '') : l;
    }).filter(Boolean);
  }

  function recipeCard(r, cur) {
    var art = document.createElement('article');
    art.className = 'recipe';
    var img = document.createElement('div');
    img.className = 'recipe-img' + (r.image_url ? '' : ' empty');
    if (r.image_url) {
      var im = document.createElement('img');
      im.src = r.image_url; im.alt = r.titre || ''; im.loading = 'lazy';
      img.appendChild(im);
    }
    var body = document.createElement('div');
    body.className = 'recipe-body';

    var meta = document.createElement('div');
    meta.className = 'recipe-meta';
    var bits = [];
    if (r.duree_min) bits.push(r.duree_min >= 60 ? Math.floor(r.duree_min / 60) + ' h' + (r.duree_min % 60 ? ' ' + (r.duree_min % 60) : '') : r.duree_min + ' min');
    if (r.personnes) bits.push(r.personnes + (r.personnes > 1 ? ' personnes' : ' personne'));
    bits.forEach(function (t) { var s = document.createElement('span'); s.textContent = t; meta.appendChild(s); });
    if ((r.mois || []).length && r.mois.indexOf(cur) >= 0) {
      var tag = document.createElement('span');
      tag.className = 'recipe-tag';
      tag.textContent = 'De saison';
      meta.appendChild(tag);
    }
    if (meta.childNodes.length) body.appendChild(meta);

    var h = document.createElement('h3'); h.textContent = r.titre; body.appendChild(h);
    if (r.description) { var p = document.createElement('p'); p.textContent = r.description; body.appendChild(p); }

    var ing = cleanLines(r.ingredients, false), steps = cleanLines(r.etapes, true);
    if (ing.length || steps.length) {
      var det = document.createElement('details');
      det.className = 'recipe-more';
      var sum = document.createElement('summary');
      sum.textContent = 'Voir la recette';
      det.appendChild(sum);
      var inner = document.createElement('div');
      inner.className = 'recipe-detail';
      if (ing.length) {
        var h4 = document.createElement('h4'); h4.textContent = 'Ingrédients'; inner.appendChild(h4);
        var ul = document.createElement('ul');
        ing.forEach(function (t) { var li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
        inner.appendChild(ul);
      }
      if (steps.length) {
        var h4b = document.createElement('h4'); h4b.textContent = 'Préparation'; inner.appendChild(h4b);
        var ol = document.createElement('ol');
        steps.forEach(function (t) { var li = document.createElement('li'); li.textContent = t; ol.appendChild(li); });
        inner.appendChild(ol);
      }
      det.appendChild(inner);
      body.appendChild(det);
    }
    art.appendChild(img); art.appendChild(body);
    return art;
  }

  function recipesJsonLd(list) {
    var graph = list.map(function (r) {
      var o = { '@type': 'Recipe', name: r.titre };
      if (r.description) o.description = r.description;
      if (r.image_url) o.image = [r.image_url];
      if (r.duree_min) o.totalTime = 'PT' + r.duree_min + 'M';
      if (r.personnes) o.recipeYield = r.personnes + ' personnes';
      var ing = cleanLines(r.ingredients, false), st = cleanLines(r.etapes, true);
      if (ing.length) o.recipeIngredient = ing;
      if (st.length) o.recipeInstructions = st.map(function (t) { return { '@type': 'HowToStep', text: t }; });
      return o;
    });
    var tag = document.createElement('script');
    tag.type = 'application/ld+json';
    tag.textContent = JSON.stringify({ '@context': 'https://schema.org', '@graph': graph });
    document.head.appendChild(tag);
  }

  function loadRecipes() {
    var sec = document.querySelector('[data-recipes-section]');
    if (!sec || !sb) return Promise.resolve();
    var box = sec.querySelector('[data-recipes]');
    var empty = sec.querySelector('[data-recipes-empty]');
    var err = sec.querySelector('[data-recipes-error]');
    var bar = sec.querySelector('[data-recipe-filters]');
    return sb.from('recettes').select('*').eq('publie', true)
      .order('created_at', { ascending: false }).order('id', { ascending: false })
      .then(function (res) {
        if (res.error) {
          // Table absente (migration pas encore exécutée) : message neutre pour les visiteurs
          var missing = res.error.code === 'PGRST205' || res.error.code === '42P01' || /does not exist|schema cache/i.test(res.error.message || '');
          (missing ? empty : err).hidden = false;
          return;
        }
        var all = res.data || [];
        if (!all.length) { empty.hidden = false; return; }
        var cur = parisNow().month;
        var seasonal = all.filter(function (r) { return !(r.mois || []).length || r.mois.indexOf(cur) >= 0; });
        var active = 'all';

        function draw() {
          box.textContent = '';
          (active === 'now' ? seasonal : all).forEach(function (r) { box.appendChild(recipeCard(r, cur)); });
        }
        function drawFilters() {
          bar.textContent = '';
          [['all', 'Toutes les recettes'], ['now', 'De saison en ' + MONTHS[cur - 1]]].forEach(function (f) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'cat-btn' + (f[0] === active ? ' active' : '');
            b.setAttribute('aria-pressed', f[0] === active ? 'true' : 'false');
            b.textContent = f[1];
            b.addEventListener('click', function () { active = f[0]; drawFilters(); draw(); });
            bar.appendChild(b);
          });
        }
        if (seasonal.length && seasonal.length < all.length) { bar.hidden = false; drawFilters(); }
        draw();
        recipesJsonLd(all);
      }).catch(function () { err.hidden = false; });
  }


  /* ---------- Galerie photos + agrandissement ---------- */
  function openLightbox(items, start) {
    var i = start;
    var dlg = document.createElement('dialog');
    dlg.className = 'lightbox';
    dlg.setAttribute('aria-label', 'Photo agrandie');
    var img = document.createElement('img');
    var cap = document.createElement('p');
    function btn(cls, label, text, fn) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'lb-btn ' + cls; b.setAttribute('aria-label', label); b.textContent = text;
      b.addEventListener('click', fn);
      return b;
    }
    function show() {
      img.src = items[i].image_url;
      img.alt = items[i].legende || '';
      cap.textContent = items[i].legende || '';
      cap.hidden = !items[i].legende;
    }
    function go(d) { i = (i + d + items.length) % items.length; show(); }
    dlg.appendChild(btn('lb-close', 'Fermer', '✕', function () { dlg.close(); }));
    if (items.length > 1) {
      dlg.appendChild(btn('lb-prev', 'Photo précédente', '‹', function () { go(-1); }));
      dlg.appendChild(btn('lb-next', 'Photo suivante', '›', function () { go(1); }));
    }
    dlg.appendChild(img); dlg.appendChild(cap);
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft' && items.length > 1) go(-1);
      if (e.key === 'ArrowRight' && items.length > 1) go(1);
    });
    dlg.addEventListener('close', function () { dlg.remove(); });
    document.body.appendChild(dlg);
    show();
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
  }

  function loadGallery() {
    var sec = document.querySelector('[data-gallery-section]');
    if (!sec || !sb) return Promise.resolve();
    var box = sec.querySelector('[data-gallery]');
    return sb.from('galerie').select('id,image_url,legende,ordre').order('ordre', { ascending: true }).order('id', { ascending: true })
      .then(function (res) {
        if (res.error || !res.data || !res.data.length) return;
        var items = res.data;
        box.textContent = '';
        items.forEach(function (it, idx) {
          var b = document.createElement('button');
          b.type = 'button'; b.className = 'gal-item';
          b.setAttribute('aria-label', 'Agrandir la photo' + (it.legende ? ' : ' + it.legende : ''));
          var im = document.createElement('img');
          im.src = it.image_url; im.alt = it.legende || ''; im.loading = 'lazy'; im.decoding = 'async';
          b.appendChild(im);
          if (it.legende) { var c = document.createElement('span'); c.className = 'gal-cap'; c.textContent = it.legende; b.appendChild(c); }
          b.addEventListener('click', function () { openLightbox(items, idx); });
          box.appendChild(b);
        });
        sec.hidden = false;
      }).catch(function () {});
  }

  /* ---------- Formulaire de contact (Supabase + repli Netlify Forms) ---------- */
  var form = document.getElementById('contact-form');
  if (form) {
    // Récapitulatif de la réservation (produits choisis sur le site)
    var recap = document.getElementById('resa-recap');
    var msgArea = document.getElementById('message');
    var msgLabel = document.querySelector('label[for="message"]');
    var msgLabel0 = msgLabel ? msgLabel.textContent : '';
    var msgHolder0 = msgArea ? msgArea.getAttribute('placeholder') : '';
    var hadItems = false;

    function drawRecap() {
      if (!recap) return;
      var list = document.getElementById('resa-list');
      var totalEl = document.getElementById('resa-total');
      list.textContent = '';
      if (!resa.length) {
        recap.hidden = true;
        msgArea.required = true;
        if (msgLabel) msgLabel.textContent = msgLabel0;
        msgArea.setAttribute('placeholder', msgHolder0);
        hadItems = false;
        return;
      }
      recap.hidden = false;
      msgArea.required = false;
      if (msgLabel) msgLabel.textContent = 'Un mot en plus (facultatif)';
      msgArea.setAttribute('placeholder', 'Une précision, une question…');
      hadItems = true;
      resa.forEach(function (it) {
        var li = document.createElement('li');
        li.className = 'resa-item';
        var nm = document.createElement('span');
        nm.className = 'resa-name';
        nm.textContent = it.nom;
        li.appendChild(nm);
        if (it.prix !== null) {
          var pr = document.createElement('span');
          pr.className = 'resa-price';
          pr.textContent = fmt.format(it.prix * it.qty);
          li.appendChild(pr);
        }
        li.appendChild(buildStepper(it));
        var rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'resa-rm';
        rm.setAttribute('aria-label', 'Retirer ' + it.nom + ' de ma réservation');
        rm.textContent = '✕';
        rm.addEventListener('click', function () { resaSet(it, 0); });
        li.appendChild(rm);
        list.appendChild(li);
      });
      var tot = resaTotal();
      totalEl.textContent = tot !== null ? 'Total indicatif : ' + fmt.format(tot) + ' (à régler au retrait)' : '';
      totalEl.hidden = tot === null;
      applyResaFocus(recap);
    }
    var clearBtn = document.getElementById('resa-clear');
    if (clearBtn) clearBtn.addEventListener('click', resaClear);
    drawRecap();
    onResa(function () { drawRecap(); });

    var status = document.getElementById('form-status');
    var btn = form.querySelector('button[type=submit]');

    function sendNetlifyFallback(finalMessage) {
      var params = new URLSearchParams(new FormData(form));
      params.set('message', finalMessage);
      var body = params.toString();
      return fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
      }).then(function (r) {
        if (!r.ok) throw new Error('http ' + r.status);
      });
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var hp = document.getElementById('bot-field');
      if (hp && hp.value) {
        form.reset();
        status.className = 'form-status ok';
        status.textContent = 'Merci ! Votre message a bien été envoyé.';
        return;
      }

      var nom = (document.getElementById('nom').value || '').trim();
      var email = (document.getElementById('email').value || '').trim();
      var telephone = (document.getElementById('telephone') ? document.getElementById('telephone').value : '').trim();
      var note = (document.getElementById('message').value || '').trim();
      var retraitEl = document.getElementById('retrait');
      var retrait = retraitEl ? retraitEl.value.trim() : '';
      var message = resa.length ? resaMessage(retrait, note) : note;
      var objet = resa.length ? 'Réservation de produits' : 'Question générale';
      var objEl = document.getElementById('objet');
      if (objEl) objEl.value = objet;

      if (!nom || !email || !message) {
        status.className = 'form-status err';
        status.textContent = 'Merci de remplir votre nom, votre email et votre message.';
        return;
      }

      btn.disabled = true;
      status.className = 'form-status';
      status.textContent = 'Envoi en cours…';

      var sendPromise = sb
        ? sb.from('messages_contact').insert({
            nom: nom,
            email: email,
            telephone: telephone || null,
            objet: objet,
            message: message
          }).then(function (res) {
            if (res.error) return sendNetlifyFallback(message);
          })
        : sendNetlifyFallback(message);

      sendPromise.then(function () {
        form.reset();
        resaClear();
        status.className = 'form-status ok';
        status.textContent = 'Merci ! Votre message a bien été envoyé, nous vous répondons rapidement.';
      }).catch(function () {
        status.className = 'form-status err';
        status.textContent = "L'envoi a échoué. Vous pouvez nous joindre directement par téléphone.";
      }).then(function () {
        btn.disabled = false;
      });
    });
  }

  setupResaBar();
  loadContent();
  loadProducts();
  loadMap();
  loadSeason();
  loadRecipes();
  loadGallery();
})();
