# Site Vitrine Maraîcher — Version Fusionnée (Supabase + Netlify)

Cette version combine votre socle existant (Supabase Auth + `is_admin()`, multi-pages, carte Leaflet + Nominatim, polices locales `Fraunces`/`Inter`, mentions légales RGPD, `/ping`) avec les nouvelles fonctionnalités :

- **Navigation en 5 onglets clairs** : *Accueil*, *Nos récoltes* (`recoltes.html` dédié aux produits et filtres), *Le Domaine*, *Marchés & horaires* (`marches.html` dédié aux horaires et à la carte Leaflet) et *Contact*.
- **Onglet `✉️ Messages` dans `/admin`** : lecture des messages envoyés depuis la page Contact, compteur de non-lus, bouton *Marquer comme lu*, réponse rapide par email et suppression.
- **Bouton `Réserver →` sur chaque produit** : redirige vers `/contact` en pré-remplissant automatiquement l'objet et le message.
- **Filtres par catégorie** (*Légumes, Fruits, Aromates, Paniers, Autres*) sur la page *Nos récoltes*.
- **Bandeau d'annonce dynamique** tout en haut du site (éditable dans *Textes & photos → Général*, masqué automatiquement s'il est vide).
- **Aperçu photo en direct** avant l'ajout d'un produit + feuille de style complète `css/admin.css`.

## Mise en place en 2 étapes

### 1. Exécuter la migration SQL dans Supabase (non-destructive)
Ouvrez votre projet Supabase → **SQL Editor** → **New query**, collez le contenu de `supabase-migration.sql` puis cliquez sur **Run**.  
Aucune donnée existante n'est supprimée ou modifiée.

*(Le site fonctionne déjà même avant cette étape : les filtres et la boîte de réception s'activent automatiquement dès que le script est exécuté.)*

### 2. Déployer sur Netlify
Déployez directement le dossier `site-maraicher-v2` (ou le fichier `site-maraicher-v2.zip`) sur Netlify :
- `_headers` et `_redirects` sont déjà nommés correctement (sans `.txt`).
- L'arborescence `/css/`, `/js/`, `/fonts/` correspond à tous les chemins HTML.

## Nouveautés v2_5

- **Bandeau « Ouvert maintenant / Aujourd'hui / Prochaine vente »** (accueil et page Marchés) : calculé automatiquement à partir des horaires saisis dans *Textes & photos → Marchés & horaires* (une ligne par lieu : `Mardi : Marché de la Vieille Ville — 7h à 13h`). Fonctionne avec « Mardi et vendredi », « Du mardi au jeudi », « Tous les jours ». Heure de Paris.
- **Itinéraire** : Google Maps + Apple Plans sur chaque point de vente (carte et liste).
- **Calendrier de saison** (page *Nos récoltes*) : onglet admin **Calendrier**, un produit = 12 boutons de mois. Le mois en cours est mis en avant et la liste « En ce moment » se génère seule.
- **Recettes de saison** (page `recettes.html`, nouveau lien dans le menu) : onglet admin **Recettes** (titre, durée, personnes, ingrédients, étapes, photo, mois, brouillon/publiée). Données structurées Google « Recipe » ajoutées automatiquement.
- Menu mobile (burger) activé en dessous de 960 px (6 liens dans la navigation).

### Mise en service v2_5
1. Si ce n'est pas déjà fait : exécuter `supabase-migration.sql` (v2_4).
2. Exécuter **`supabase-migration-v2_7.sql`** dans le SQL Editor de Supabase (crée `calendrier_saison`, `recettes`, 15 produits de saison et une recette d'exemple à adapter).
3. Redéployer le dossier sur Netlify.

## v2_6 : finitions visuelles

- **Boutons unifiés** : un seul système (hauteur, rayon, ombre légère, flèche automatique) avec variantes `btn-primary` (plein), `btn-ghost` (contour), `btn-light` (sur fond vert), `btn-sm`. Les liens texte (`link-arrow`) et les filtres suivent le même style ; « Réserver » devient une petite pastille.
- Bandeau « ouvert aujourd'hui » repensé (bouton « Voir la carte » intégré).
- Corrections : trait parasite sous le texte des cartes, prix « Prix sur étal » coupé sur deux lignes, espaces insécables avant `? ! : ;` (même pour les textes saisis dans l'admin), lien « Répondre » de l'admin (`@` conservé), photos avec dimensions (moins de décalage au chargement), contraste des petits titres.
- La page Recettes affiche « Les premières recettes arrivent bientôt » tant que la migration v2_5 n'est pas exécutée (au lieu d'une erreur).

## v2_7 : « Qui sommes-nous » et galerie photos

- La page **Le Domaine** devient **Qui sommes-nous** (`/qui-sommes-nous`, l'ancienne adresse `/exploitation` redirige automatiquement). Tout se modifie dans l'admin, onglet **Textes & photos → Qui sommes-nous** : introduction, *Notre histoire* (texte, signature, photo portrait), jusqu'à 4 **chiffres clés** (ex : « 2018 / année d'installation »), citation, textes de culture. Les blocs *Notre histoire* et *Chiffres* n'apparaissent que lorsqu'ils sont remplis.
- Nouvel onglet admin **Galerie** : ajout de plusieurs photos d'un coup, légende, ordre (◀ ▶), suppression. Elles s'affichent dans « En images » avec agrandissement (flèches du clavier, Échap pour fermer).
- La ligne « Cueilli le matin même · Sans chimie de synthèse · 100 % circuit court » a été retirée de l'accueil.
- **SQL** : `supabase-migration-v2_7.sql` remplace l'ancien fichier v2_5 (il contient aussi le calendrier et les recettes). À exécuter après `supabase-migration.sql`, relançable sans risque.

## Nouveautés v2_8 — Réservation de plusieurs produits en un seul message
- Sur chaque fiche produit : bouton « + Ajouter », puis sélecteur de quantité (− / +) avec l'unité du produit (kg et litre par demi-unité, les autres par unité).
- Barre flottante « N produits dans ma réservation » → page Contact.
- Page Contact : récapitulatif modifiable (quantités, retrait d'un produit, « Tout retirer »), champ « Marché ou jour de retrait », total indicatif si tous les prix sont renseignés. Un seul message est envoyé, avec la liste complète (visible dans l'admin, onglet Messages).
- La sélection est mémorisée sur l'appareil du visiteur ; les produits devenus indisponibles sont retirés automatiquement.
- Aucun paiement en ligne. Aucune modification de la base : le fichier SQL reste `supabase-migration-v2_7.sql`.

## Nouveautés v2_9 — Page 404
- `404.html` : page « Ce légume n'a pas poussé ici » aux couleurs du site (Netlify l'affiche automatiquement pour toute adresse inconnue). Non indexée par Google. Aucune modification de la base.

## Nouveautés v2_10
- Formulaire de contact : champ « Objet » supprimé (l'objet est déduit : « Réservation de produits » si des produits sont choisis, sinon « Question générale » ; il reste visible dans l'admin).
- `403.html` : page « Cette parcelle est réservée ». Les fichiers techniques (`supabase-migration*.sql`, `README.md`) renvoient cette page 403 via `_redirects` pour ne pas être lisibles publiquement. Si vous ajoutez un nouveau fichier .sql, ajoutez une ligne équivalente dans `_redirects`.
- Finitions : grilles produits/recettes qui remplissent la largeur, images produit plus basses sur mobile, ligne d'accroche de l'accueil sans retour à la ligne bancal, espacement entre sections resserré.
